package com.vmware.myvmware.sr.basePackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestParam;

import com.vmware.myvmware.sr.util.SRBusinessLogic;

;

/*
 *	Query - "MATCH (n:EntAccounts) where n.EANumber MATCH (c:Users {UserId}) MATCH (c)-[:FILE_SR]->(f:Folders), (f)<-[p:PROD_BELONGS_TO]-(p1:Products), (p1)-[s:SUPP_LEVEL] ->(s1:SuppLevel)  where  s1.ImportanceLevel <> \"1300\" return distinct s1.ImportanceLevel, s1.SupportProductId, s1.SubTypeDescription order by s1.SupportProductId" 
 * 
 */
public class SRDaoImpl {

	Driver driver;
	Session session;

	@Value("${url}")
	String neo4jURL;
	@Value("${userName}")
	String neo4jUserName;
	@Value("${password}")
	String neo4jPassword;

	boolean mcsBcsUser = false;
	boolean superUser = false;
	String mcsBcsContractType = "";
	String mcsBcsImportanceLevel = "";
        ArrayList<String> Prereq = new ArrayList<String>();//Added for pre req check
        ArrayList<Integer> Exclarr = new ArrayList<Integer>();//Added for Excl check

	String eaName = "";
	String customerNumber = "";
	String email = "";
	String entitlementCode = "";
	
	public void init(String eANumber, String userId) {
            		// Initialize Driver
		driver = GraphDatabase.driver(neo4jURL,
				AuthTokens.basic(neo4jUserName, neo4jPassword));
		session = driver.session();
                
///driver = GraphDatabase.driver( "bolt://ems-lab-nosql-1.vmware.com", AuthTokens.basic( "neo4j", "welcome1" ) );
///session = driver.session();
		/***********************************************************************************************************/

		// Get SU status on the provided entitlement account and user id
		// provided
		String isSuperUserQuery = "MATCH(n:EntAccounts {EANumber :\""
				+ eANumber + "\"})<-[u:USER_ROLE]-(u1:Users {UserId:" + userId
				+ "}) RETURN u.role as role";
		StatementResult result = session.run(isSuperUserQuery);

		
		 if (result.hasNext()) { 
			 superUser = true;
		}
		 
		/**********************************************************************************************************/

		// Get MCS/BCS Status on the provided EA

		String isMcsBcsUserQuery ="MATCH(n:SuppLevel {EaNumber :\""+eANumber+"\"}) MATCH (u:Users {UserId:"+userId+"}),(u) - [fr:FILE_SR] -> (n) Return n.SiebelShortDescription  as contract, n.ImportanceLevel as importance, n.DetailedDescription";
		result = session.run(isMcsBcsUserQuery);

		List<Record> records = result.list();
                      System.out.println("MCS/BCS Block");

		if (!records.isEmpty()) {
 System.out.println("Inside MCS/BCS Block");
			int i = 0;
			mcsBcsUser = true;
			Record record = records.get(i);
			i++;
			mcsBcsContractType = record.get("contract").asString();
			mcsBcsImportanceLevel = record.get("importance").asString();

			while (i < records.size()) {
				record = records.get(i);
				i++;
				int importanceLevel = Integer.parseInt(record.get("importance")
						.asString());
				if (importanceLevel < Integer.parseInt(mcsBcsImportanceLevel)) {
					mcsBcsContractType = record.get("contract").asString();
					mcsBcsImportanceLevel = record.get("importance").asString();
				}
			}

		}
		
                //Pre req check
                String InclQuery="MATCH (p:PreRequisite) where p.LookupType = \"XXVM_ENTLMENT_INCL_IMP_LEVEL\" and p.ImportanceLevel =\""+mcsBcsImportanceLevel+"\" return p.SuppProdId as prereq";
                
                result = session.run(InclQuery);

		List<Record> Inc = result.list();
                 System.out.println("Pre Req Block");

		if (!Inc.isEmpty()) {
                     System.out.println("Inside Pre Req Block"+Inc.size());
                    int i = 0;
                        while (i < Inc.size())
                        {
                            System.out.println("Pre req size while loop"
					+ Prereq.size() );
                          Record record1 = Inc.get(i);
                          System.out.println("I"+ i+record1.get("prereq").asString());
                          String vd = record1.get("prereq").asString();
			Prereq.add(vd);
                       System.out.println("Pre req size initial value"
					+ Prereq.get(i));
                        i++;                    
                        }
                          System.out.println("Printing i "+i );
                        System.out.println("Pre req size initial"
					+ Prereq.size() );
		}
               
                // Exclusion query
                
                if (superUser) {
// If the user is Super User
	System.out.println("Super User Excl_List");
	String ExclQuery = "match (f:Folders{EANumber:\""+eANumber+"\"}) match (f)<-[p:PROD_BELONGS_TO]-(p1:Products) match (p1)-[s:SUPP_LEVEL] ->(s1:SuppLevel)MATCH (pr:PreRequisite{}),(s1)-[cr:CONTRACT_TYPE] ->(cnt:Contracts)  where   pr.LookupType =  \"XXVM_ENTLMENT_EXCL_PROD_FAMILY\" and pr.ImportanceLevel= \"40\" and toint(pr.SuppProdId) = s1.SupportProductId and s1.ImportanceLevel <> \"1300\" and cnt.Status = \"ACTIVE\" return  distinct s1.ImportanceLevel as importanceLevel, s1.SupportProductId  as supportProductId, p1.ProdLineDesc as productFamily,  p1.SupportDescription as productName, s1.SubTypeDescription as subTypeDescription, s1.SiebelShortDescription as eaCode order by s1.SupportProductId ";
	System.out.println(ExclQuery);			
        result = session.run(ExclQuery);
        List<Record> excl = result.list();
        System.out.println("Excl Block");

		if (!excl.isEmpty()) {
                     System.out.println("Inside excl Block"+excl.size());
                     System.out.println("after change" );
                    int i = 0;
                        while (i < excl.size())
                        {
                            System.out.println("excl while loop"
					+ excl.size() );
                              System.out.println("after change" );
                          Record record2 = excl.get(i);
                          System.out.println("I value"+ i+record2.get("supportProductId").asInt());
                         Integer vd1 = record2.get("supportProductId").asInt();
			///String vd2 = Integer.toString(vd1);
                          Exclarr.add(vd1);
                       System.out.println("excl initial value"
					+ Exclarr.get(i));
                        i++;                    
                        }
                          System.out.println("Printing i "+i );
                        System.out.println("Pre req size initial"
					+ Exclarr.size() );
		}
             } else {
				// If user is normal user
	System.out.println("Normal User Exclusion");
    	String ExclQuery = "MATCH (c:Users {UserId: "+userId+"}) MATCH (c)-[:FILE_SR]->(f:Folders{EANumber: \""+eANumber+"\"}) MATCH (pr:PreRequisite) ,(f)<-[p:PROD_BELONGS_TO]-(p1:Products),  (p1)-[s:SUPP_LEVEL] ->(s1:SuppLevel), (s1)-[cr:CONTRACT_TYPE] ->(cnt:Contracts)  where  pr.LookupType =  \"XXVM_ENTLMENT_EXCL_PROD_FAMILY\" and pr.ImportanceLevel= \"40\" and toint(pr.SuppProdId) = s1.SupportProductId and  toint(pr.SuppProdId) = p1.ProductId and s1.ImportanceLevel <> \"1300\"  and cnt.Status = \"ACTIVE\"  return  distinct s1.ImportanceLevel as importanceLevel, s1.SupportProductId as supportProductId, p1.ProdLineDesc as productFamily, p1.SupportDescription as productName,  s1.SubTypeDescription as subTypeDescription, s1.SiebelShortDescription as eaCode order by s1.SupportProductId";
	System.out.println(ExclQuery);			
        result = session.run(ExclQuery);
        List<Record> excl = result.list();
        System.out.println("Excl Block");

		if (!excl.isEmpty()) {
                     System.out.println("Inside excl Block"+excl.size());
                    int i = 0;
                        while (i < excl.size())
                        {
                            System.out.println("excl while loop"
					+ excl.size() );
                          Record record2 = excl.get(i);
                          System.out.println("I value"+ i+record2.get("supportProductId").asInt());
                         Integer vd1 = record2.get("supportProductId").asInt();
			///String vd2 = Integer.toString(vd1);
			Exclarr.add(vd1);
                       System.out.println("excl initial value"
					+ Exclarr.get(i));
                        i++;                    
                        }
                          System.out.println("Printing i "+i );
                        System.out.println("Pre req size initial"
					+ Exclarr.size() );
		}	
			}
                
    
                
             	// Query to identify the EA Name and Customer Number
		
		String userDetailsQuery = "MATCH(n:EntAccounts {EANumber :\""+eANumber+"\"}) MATCH (u:Users {UserId:"+userId+"}) return n.EAName as eAName,u.Email as email,u.CN as customerNumber";
		StatementResult sr = session.run(userDetailsQuery);

		if(sr.hasNext()){
			Record r = sr.next();
			eaName = r.get("eAName").asString();
			email = r.get("email").asString();
			customerNumber = r.get("customerNumber").asString();
			entitlementCode = r.get("entitlementCode").asString();
		}
	}

	/*
	 * Close the connection with Server
	 */
	public void terminateConnection() {
		driver.close();
		session.close();
	}

	@GET
	@Produces("application/json")
	public List<FamilyProducts> getRecordsByGroup(
			@RequestParam Map<String, String> inParams) {

		String entitlementAccount = inParams.get("eANumber");
		String userId = inParams.get("userId");

		StatementResult result;
                StatementResult exclresult;
		List<SREligibility> initialList = new ArrayList<>();
                List<SREligibility> initialList2 = new ArrayList<>();
		List<SREligibility> finalList;
		Map<String, List<Products>> finalMap;
		Long start_time = System.currentTimeMillis();
		List<FamilyProducts> products;
		try {
			Long start_time_nano = System.nanoTime();
			System.out.println();
			System.out
					.println("********************************************************************");

			System.out.println();
			System.out.println("Getting details for : " + entitlementAccount
					+ " EA# and " + userId + " userId");
			System.out.println();
			init(entitlementAccount, userId);

			if (superUser) {
				// If the user is Super User
				System.out.println("Super User");
				String superUserQuery = "match (f:Folders{EANumber:\""+entitlementAccount+"\"}) match (f)<-[p:PROD_BELONGS_TO]-(p1:Products)  match (p1)-[s:SUPP_LEVEL] ->(s1:SuppLevel), (s1)-[cr:CONTRACT_TYPE] ->(cnt:Contracts)  where  s1.ImportanceLevel <> \"1300\" and cnt.Status = \"ACTIVE\" return  distinct s1.ImportanceLevel as importanceLevel, s1.SupportProductId as supportProductId, p1.ProdLineDesc as productFamily, p1.SupportDescription as productName, s1.SubTypeDescription as subTypeDescription, s1.SiebelShortDescription as eaCode order by s1.SupportProductId";
				result = session.run(superUserQuery);
				superUser = false;
			} else {
				// If user is normal user
				System.out.println("Normal User");
				String normalUserQuery = "MATCH (c:Users {UserId: "+userId+"}) MATCH (c)-[:FILE_SR]->(f:Folders{EANumber:\""+entitlementAccount+"\"}), (f)<-[p:PROD_BELONGS_TO]-(p1:Products), (p1)-[s:SUPP_LEVEL] ->(s1:SuppLevel),(s1)-[cr:CONTRACT_TYPE] ->(cnt:Contracts)   where  s1.ImportanceLevel <> \"1300\" and cnt.Status = \"ACTIVE\" return  distinct s1.ImportanceLevel as importanceLevel, s1.SupportProductId as supportProductId, p1.ProdLineDesc as productFamily, p1.SupportDescription as productName, s1.SubTypeDescription as subTypeDescription, s1.SiebelShortDescription as eaCode order by s1.SupportProductId";
				System.out.println("Nomal User Query"+normalUserQuery);
                                result = session.run(normalUserQuery);
			}

			Long start_bussiness_logic = System.currentTimeMillis();
			System.out.println();
			System.out.println("Checkpoint 1 - Get the raw data : "
					+ (System.currentTimeMillis() - start_time) / 1000 + "s, "
					+ (System.currentTimeMillis() - start_time) % 1000 + "ms, "
					+ (System.nanoTime() - start_time_nano) / 1000
					+ " nanoseconds");
			while (result.hasNext()) {
				Record record = result.next();
				initialList.add(new SREligibility(record
						.get("supportProductId").asInt(), record.get(
						"importanceLevel").asString(), record.get(
						"subTypeDescription").asString(), record.get(
						"productFamily").asString(), record.get("productName")
						.asString(),eaName, email, customerNumber, record.get("eaCode").asString()));
			}
                                             
			System.out
					.println("Checkpoint 2 - Processed all the records, created raw list : "
							+ (System.currentTimeMillis() - start_time)
							/ 1000
							+ "s, "
							+ (System.currentTimeMillis() - start_time)
							% 1000
							+ "ms, "
							+ (System.nanoTime() - start_time_nano)
							/ 1000
							+ " nanoseconds");
                       	SRBusinessLogic srb = new SRBusinessLogic();
			System.out.println("Checkpoint 3 - Initiating reOrder : "
					+ (System.currentTimeMillis() - start_time) / 1000 + "s, "
					+ (System.currentTimeMillis() - start_time) % 1000 + "ms, "
					+ (System.nanoTime() - start_time_nano) / 1000
					+ " nanoseconds");
			finalList = srb.reOrder(initialList);
			System.out.println("Checkpoint 4 - ReOrder Complete : "
					+ (System.currentTimeMillis() - start_time) / 1000 + "s, "
					+ (System.currentTimeMillis() - start_time) % 1000 + "ms, "
					+ (System.nanoTime() - start_time_nano) / 1000
					+ " nanoseconds");
			finalMap = srb.groupByProductFamily(finalList, entitlementAccount);
			System.out.println("Checkpoint 5 - Added products to groups: "
					+ (System.currentTimeMillis() - start_time) / 1000 + "s, "
					+ (System.currentTimeMillis() - start_time) % 1000 + "ms, "
					+ (System.nanoTime() - start_time_nano) / 1000
					+ " nanoseconds");
                    if (mcsBcsUser) {
                        
                        
				finalList = srb.reOrder(srb.reOrder(initialList),Prereq,Exclarr,
						mcsBcsContractType, mcsBcsImportanceLevel, eaName, email, customerNumber, entitlementCode);
				System.out.println("Checkpoint 6 - ReOrder Complete for "
						+ mcsBcsContractType + " contract type: "
						+ (System.currentTimeMillis() - start_time) / 1000
						+ "s, " + (System.currentTimeMillis() - start_time)
						% 1000 + "ms, " + (System.nanoTime() - start_time_nano)
						/ 1000 + " nanoseconds");
				finalMap = srb.groupByProductFamily(finalList, entitlementAccount);
				System.out
						.println("Checkpoint 7 - Added products to groups after reOrdering: "
								+ (System.currentTimeMillis() - start_time)
								/ 1000
								+ "s, "
								+ (System.currentTimeMillis() - start_time)
								% 1000
								+ "ms, "
								+ (System.nanoTime() - start_time_nano)
								/ 1000
								+ " nanoseconds");
				mcsBcsUser = false;
                                Prereq = new ArrayList<String>();
                                Exclarr = new ArrayList<Integer>();
			}
			products = new ArrayList<FamilyProducts>();
			for (String str : finalMap.keySet()) {
				String familyName = str;
				List<Products> familyMembers = finalMap.get(familyName);
				products.add(new FamilyProducts(familyName, familyMembers));
			}

			System.out.println();
			System.out.println("Total records retrieved from DB - "
					+ initialList.size());
			System.out
					.println("Applied bussiness logic and ranking to records to return - "
							+ finalList.size() + " records");
			System.out.println("Total Product Families created - "
					+ products.size());
			Long end_time = System.currentTimeMillis();
			System.out
					.println("Total time taken to complete the total operation - "
							+ ((end_time - start_time) / 1000)
							+ " seconds, "
							+ (System.currentTimeMillis() - start_time)
							% 1000
							+ " milliseconds");
			System.out
					.println("Total time taken to complete processing records and applying bussiness logic - "
							+ ((end_time - start_bussiness_logic) / 1000)
							+ " seconds, "
							+ (System.currentTimeMillis() - start_bussiness_logic)
							% 1000 + " milliseconds");
		} catch (Exception e) {
			System.out
					.println("Exception occured - " + e.getLocalizedMessage());
			e.printStackTrace();
			products = null;
		} finally {
			this.terminateConnection();
			System.out.println("Closed the connection successfully");
			System.out.println();
			System.out
					.println("********************************************************************");
			superUser = false;
		}

		return products;
	}

}
