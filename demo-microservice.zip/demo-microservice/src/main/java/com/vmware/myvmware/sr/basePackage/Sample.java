package com.vmware.myvmware.sr.basePackage;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class Sample{

	
	@RequestMapping("/greeting")
	public String greeting() {
       // model.addAttribute();
       return "redirect:src/main/resources/templates/index.html";
	}
	
}
