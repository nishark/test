package com.vmware.myvmware.sr.basePackage;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/createSR")
public class CreateSRController extends CreateSRDaoImpl {

	@CrossOrigin
	@RequestMapping("/getResponse")
	public String fileSRAndgetResponse(@RequestParam Map<String, String> inParams) throws SOAPException, IOException{
		return super.fileSRAndGetResponse(inParams);

	}

}
