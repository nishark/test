package com.vmware.myvmware.sr;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.neo4j.config.EnableNeo4jRepositories;
import org.springframework.data.neo4j.config.Neo4jConfiguration;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.vmware.myvmware.sr.basePackage.CreateSRDaoImpl;


/*
 * 
 * isFilterChecked:
Y
2.	issueDetailsVo.technicalProblemCategory:
Installation
3.	issueDetailsVo.liceseProblemCategory:
4.	issueDetailsVo.customerProblemCategory:
5.	userSelectedEntitlementAccount:
313377584-qatest1436
6.	customerNumber:
6527586636
7.	defaultEntitlementAccount:
313377584
8.	productObj:
com.vmware.support.vo.ProductVo@467ab762
9.	srIssueType:
tsr
10.	filterProductListBy:
11.	productVo.selectedProduct:
VMware vSphere Data Protection Advanced 5.x
12.	technicalProductURL:
13.	isMAProduct:
false
14.	megerAndAcquistionProductMessage:
Support for the selected product is managed through another system. When you click Continue Support Request, a new window will open. After logging in, you can submit a Support Request.
15.	incidentPackSerialNumber:
16.	incidentCount:
 * 
 * */

@SpringBootApplication
@EnableNeo4jRepositories
public class DemoMicroserviceApplication extends Neo4jConfiguration{

	public DemoMicroserviceApplication(){
		setBasePackage("com.vmware.myvmware.sr.basePackage");
		
	}
	
	@Bean(destroyMethod="shutdown")
	public GraphDatabaseService graphDatabaseService(){
		
		return new GraphDatabaseFactory().newEmbeddedDatabase("C:\\Users\\ajitg\\Spring Workspace\\gs-accessing-neo4j-data-rest-complete\\target\\hello.db");
	}
	
	public static void main(String[] args) throws Exception{
	
		SpringApplication.run(DemoMicroserviceApplication.class, args);
	
	
	}

}
