package com.vmware.myvmware.sr.basePackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

public class CreateSRDaoImpl {

	public String fileSRAndGetResponse(Map<String, String> inParams)
			throws SOAPException, IOException {

		// ----------Product Details----------------
		String subTypeDescription = inParams.get("subTypeDescription");
		String productName = inParams.get("productName");
		String eaName = inParams.get("eaName");
		String email = inParams.get("email");
		String customerNumber = inParams.get("customerNumber");
		String entitlementCode = inParams.get("entitlementCode");
		String description = inParams.get("description");
		String eaNumber = inParams.get("eaNumber");

		// -----------------------------------------
		FileInputStream fis = new FileInputStream(new File("/opt/springsource/home/hqa/CreateSR.xml"));

		MessageFactory factory = MessageFactory.newInstance();// SOAPConstants.SOAP_1_2_PROTOCOL
		MimeHeaders header = new MimeHeaders();
		SOAPMessage message = factory.createMessage(header, fis);
		
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:ContactCN").item(0).setTextContent(customerNumber);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:ContactEmailAddress").item(0).setTextContent(email);  
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:Description").item(0).setTextContent(description);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:Entitlement").item(0).setTextContent(subTypeDescription);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:EntitlementCode").item(0).setTextContent(entitlementCode);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("ser:Product").item(0).setTextContent(productName);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("com:Value").item(0).setTextContent(eaNumber);
		message.getSOAPBody().getOwnerDocument().getElementsByTagName("com:Value").item(1).setTextContent(eaName);
		
		
		System.out.println("**************Request*************");
		message.writeTo(System.out);
		SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory
				.newInstance();
		SOAPConnection soapConnection = soapConnectionFactory
				.createConnection();
		SOAPMessage soapResponse = soapConnection
				.call(message,
						"http://dev15soa.vmware.com:7777/services/CreateServiceRequest");

		System.out.println("**************Response*************");
		soapResponse.writeTo(System.out);

		String returnMessage;

		try {
			returnMessage = soapResponse.getSOAPBody().getOwnerDocument()
					.getElementsByTagName("ser:ServiceRequestNumber").item(0)
					.getTextContent();
		} catch (Exception npe) {
			returnMessage = soapResponse.getSOAPBody().getOwnerDocument()
					.getElementsByTagName("sch:errorMessage").item(0)
					.getTextContent();
		}

		soapConnection.close();

		return returnMessage;
	}

}
