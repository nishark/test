package com.vmware.myvmware.sr.basePackage;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fileSR")
public class FileSRController extends SRDaoImpl{

	@CrossOrigin
	@RequestMapping("/getProductDetails")
	public List<FamilyProducts> getRecordsByGroups(@RequestParam Map<String, String> inParams){
		return super.getRecordsByGroup(inParams);
	}
	
}
