package com.vmware.myvmware.sr.basePackage;

public class Products {

	private Number supportProductId;
	private String importanceLevel;
	private String subTypeDescription;
	private String productName;

	private String eaName;
	private String email;
	private String customerNumber;
	private String entitlementCode; 
	private String eaNumber;
	
	public Products(){}
	
	public Products(Number supportProductId, String importanceLevel, String subTypeDescription, String productName, String eaName, String email, String customerNumber, String entitlementCode, String eaNumber){
		this.supportProductId=supportProductId;
		this.importanceLevel=importanceLevel;
		this.subTypeDescription=subTypeDescription;
		this.productName=productName;
		this.eaName=eaName;
		this.email = email;
		this.customerNumber = customerNumber;
		this.entitlementCode = entitlementCode;
		this.eaNumber = eaNumber;
	}

	public Number getSupportProductId() {
		return supportProductId;
	}

	public void setSupportProductId(Number supportProductId) {
		this.supportProductId = supportProductId;
	}

	public String getImportanceLevel() {
		return importanceLevel;
	}

	public void setImportanceLevel(String importanceLevel) {
		this.importanceLevel = importanceLevel;
	}

	public String getSubTypeDescription() {
		return subTypeDescription;
	}

	public void setSubTypeDescription(String subTypeDescription) {
		this.subTypeDescription = subTypeDescription;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getEaName() {
		return eaName;
	}

	public void setEaName(String eaName) {
		this.eaName = eaName;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntitlementCode() {
		return entitlementCode;
	}

	public void setEntitlementCode(String entitlementCode) {
		this.entitlementCode = entitlementCode;
	}

	public String getEaNumber() {
		return eaNumber;
	}

	public void setEaNumber(String eaNumber) {
		this.eaNumber = eaNumber;
	}
	
	
	
}
