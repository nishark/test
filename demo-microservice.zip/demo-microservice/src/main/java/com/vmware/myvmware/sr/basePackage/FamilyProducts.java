package com.vmware.myvmware.sr.basePackage;

import java.util.List;

public class FamilyProducts {

	private String familyName;
	private List<Products> products;
	
	public FamilyProducts(){}
	
	public FamilyProducts(String familyName, List<Products> products){
		this.familyName = familyName;
		this.products=products;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public List<Products> getProducts() {
		return products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}
	
	
	
}
