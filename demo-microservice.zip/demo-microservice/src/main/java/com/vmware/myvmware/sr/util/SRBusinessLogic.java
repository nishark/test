package com.vmware.myvmware.sr.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.vmware.myvmware.sr.basePackage.Products;
import com.vmware.myvmware.sr.basePackage.SREligibility;

;

public class SRBusinessLogic {

public List<SREligibility> reOrder(List<SREligibility> initialList){
		
		
		// Find total size of list that is to be processed.
		int totalSize = initialList.size();
		
		// Only if size of list is greater than or equal to 2, process the list;
		if(totalSize > 1){
		
			// Create a new object to store processed list of items from initial list 
			List<SREligibility> newList = new ArrayList<>();
		
			// Add first element to the list directly.
			newList.add(initialList.get(0));
		
			
			// Create two objects to hold current and previous data;
			SREligibility previousProduct;
			SREligibility currentProduct;
		
			// Starting the loop from 1 because the first element is already added.
			for(int i = 1; i <= totalSize-1; i++){
			
				previousProduct = initialList.get(i-1);
				currentProduct = initialList.get(i);
				
				int prevProductId = previousProduct.getSupportProductId().intValue();
				int currProductId = currentProduct.getSupportProductId().intValue();
				
				int prevImportanceLevel = Integer.parseInt(previousProduct.getImportanceLevel());
				int currImportanceLevel = Integer.parseInt(currentProduct.getImportanceLevel());
				
				if(prevProductId == currProductId){
					
					if(prevImportanceLevel > currImportanceLevel){
						
						newList.remove(previousProduct);
						newList.add(currentProduct);
					}// Add currentProduct only if the importance level of current product is lesser than previous product.
					
				}else{
					newList.add(currentProduct);
				}// End of else block verifying product Ids equality / inequality
				
			}// End of for loop
		
						
			return newList;
		}
		
		return initialList; // Returning the same initial List as there is only one element in the list.
		
	}
	
	public List<SREligibility> reOrder(List<SREligibility> orderedList, ArrayList<String> Prereq,ArrayList<Integer> Exclarr,String supportType, String importanceLevel, String eaName, String email, String customerNumber, String entitlementCode){
		
		List<SREligibility> newList = new ArrayList<>();
                String preImp;
                int count =0 ;    
                 int length =Prereq.size();
                 int len =Exclarr.size();
                 System.out.println ("orderedList size"+ orderedList.size());
 for(SREligibility sre : orderedList){
        System.out.println("Initial List"+ sre.getImportanceLevel() +"Support pdt id"+sre.getSupportProductId() );       
       count = 0;
        for (int i = 0; i < len; i++)
         {
          System.out.println("exclusion aray list"+Exclarr.get(i));  
          Integer vd1 = Exclarr.get(i);
          Integer vd2 = (Integer)sre.getSupportProductId();
          System.out.println("vd1"+vd1);
          System.out.println("vd2" + vd2);
          
          if(vd1.equals(vd2))
             {
                 count= count+1;
                 System.out.println("Inside exclusion match ");
             }
                 
         }   
         System.out.println ("count"+count);
         if ( Prereq != null && count ==0 )
 //if ( length > 0 && count ==0 )
         {           
               System.out.println ("Length of the pre req array"+length );
                    for (int i = 0; i < length; i++)
                    {
                            System.out.println("Pre req value in business logic"
					+ Prereq.get(i) );
                    preImp  =Prereq.get(i);                    
			if(sre.getImportanceLevel().equals(preImp))
                        {
				SREligibility newSre = new SREligibility(sre.getSupportProductId(),importanceLevel,supportType,sre.getProductFamily(), sre.getProductName(), eaName, email, customerNumber, entitlementCode);
				newList.add(newSre);
                                 System.out.println("Adding rec with overwritten logic"
					+ sre.getImportanceLevel() + importanceLevel ); 
                                 break;
                                        }
			       else {
                            System.out.println("Inside inner else,printinmg i value"+i+"printing prereq.size"+Prereq.size());
                                if(i== (Prereq.size()-1)) 
                            { System.out.println("Adding rec without overwritten logic"
					+ sre.getImportanceLevel() ); 
                                    newList.add(sre);
                            }
                                }				
			}
                    }
       else
       { newList.add(sre);
       System.out.println ("Else part as there is no prereq/excluded");
       }
          System.out.println ("Support pdt id"+sre.getSupportProductId()+ "Product Count" + newList.size());
       }
 System.out.println ("New List size"+ newList.size());
 return newList;
	}
	

	
	public Map<String, List<Products>> groupByProductFamily(List<SREligibility> products, String entitlementAccount){
		
		Map<String, List<Products>> groupedProducts = new HashMap<String, List<Products>>();
		
		for(SREligibility sre : products){
			
			Products newProduct = new Products(sre.getSupportProductId(),sre.getImportanceLevel(),sre.getSubTypeDescription(),sre.getProductName(), sre.getEaName(), sre.getEmail(), sre.getCustomerNumber(), sre.getEntitlementCode(), entitlementAccount);
			
			if(groupedProducts.containsKey(sre.getProductFamily())){
				
				List<Products> currentList = groupedProducts.get(sre.getProductFamily());
				currentList.add(newProduct);
				groupedProducts.put(sre.getProductFamily(), currentList);
				 
				
			}else{
				
				List<Products> newList = new ArrayList<Products>();
				newList.add(newProduct);
				groupedProducts.put(sre.getProductFamily(), newList);
				
			}
		}
		
		return groupedProducts;
	}

}
